/**
 * 
 */
package edu.ics211.h02;

/**
 * @author isaac
 *
 */
public class Firm extends Cheese {

  /**
   * @param name
   * @param type
   * @param percentFat
   */
  protected Firm(String name, CheeseType type, Double percentFat) {
    super(name, type, percentFat);
    // TODO Auto-generated constructor stub
  }

}
